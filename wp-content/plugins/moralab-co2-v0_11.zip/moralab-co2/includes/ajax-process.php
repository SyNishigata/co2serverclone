<?php
// create ajax call

class co2_ajax_process{
	public function __construct() {
		// save tree
		add_action('wp_ajax_save_tree', Array($this, 'save_tree'));
		add_action('wp_ajax_nopriv_save_tree', Array($this, 'save_tree'));

		// save carbon emission data
		add_action('wp_ajax_save_carbon_usage', Array($this, 'save_carbon_usage'));
		add_action('wp_ajax_nopriv_save_carbon_usage', Array($this, 'save_carbon_usage'));

		// image uploaded
		add_action("wp_ajax_nopriv_image_uploader", Array($this, "image_uploader"));
		add_action("wp_ajax_image_uploader", Array($this, "image_uploader"));
	}

	public function save_tree() {
		global  $wpdb, $current_user;
      	get_currentuserinfo();

		$tree = array(
			'treeName' 		=> $_POST['treeName'],
			'location' 		=> $_POST['location'],
			'latitude' 		=> $_POST['latitude'],
			'longitude' 	=> $_POST['longitude'],
			'treeBirth' 	=> $_POST['treeBirth'],
			'treeDiameter'	=> $_POST['treeDiameter'],
			'treeUnit' 		=> $_POST['treeUnit'],
			'sequestered' 	=> $_POST['sequencial']
		);

		$args = array(
			'post_title'	=> $tree['treeName'],
			'post_content'	=> ''
		);

		if (!$_POST['new']):
			$args['ID'] = $_POST['post_id'];
			$post_id = wp_update_post($args);
		else: // a new post
			$args['post_type'] = 'tree';	
			$args['post_name'] = time();
			$args['post_status'] = 'publish';
			$args['post_author'] = $current_user->ID;
			$post_id = wp_insert_post($args);
		endif;

		// add or update tree post
		//$post_id = isset($id)? wp_update_post($args) : wp_insert_post($args);

		// Add tree meta data

		if( (int)$post_id > 0 ){
			update_post_meta($post_id, 'location', $tree['location']);
			update_post_meta($post_id, 'latitude', $tree['latitude']);
			update_post_meta($post_id, 'longitude', $tree['longitude']);
			update_post_meta($post_id, 'treeBirth', $tree['treeBirth']);
			update_post_meta($post_id, 'treeDiameter', $tree['treeDiameter']);
			update_post_meta($post_id, 'treeUnit', $tree['treeUnit']);
			update_post_meta($post_id, 'sequestered', $tree['sequestered']);

 			// update user's carbon score
			$this->update_user_carbon_score_meta($current_user->ID);
		}

		die(
			json_encode(
				Array(
					'result' => ( (int) $post_id > 0 ? true : false)
					, 'permalink' => get_permalink($post_id)
					, 'post' => $_POST['treeName']
				)
			)
		);
	}

	public function save_carbon_usage() {
		global  $wpdb, $current_user;
      	get_currentuserinfo();

		$travel = array(
			'unit_conversion' 	=> $_POST['unit_conversion'],
			'miles_year' 		=> $_POST['miles_year'],
			'miles_gallon' 		=> $_POST['miles_gallon'],
			'diesel' 			=> $_POST['diesel'],
			'transit_rail' 		=> $_POST['transit_rail'],
			'bus' 				=> $_POST['bus'],
			'miles_flown' 		=> $_POST['miles_flown'],
			'total_travel' 		=> $_POST['total_carbon']
		);
	
		$home = array(
			'electricity' 	=> $_POST['electricity'],
			'gas' 			=> $_POST['gas'],
			'term_year' 	=> $_POST['term_year'],
			'water_used' 	=> $_POST['water_used'],
			'fuels'			=> $_POST['fuels'],
			'total_house' 	=> $_POST['total_house']
			);

		$food = array(
			'beef' 			=> $_POST['beef'],
			'poultry'		=> $_POST['poultry'],
			'fish' 			=> $_POST['fish'],
			'dairy' 		=> $_POST['dairy'],
			'vegetables' 	=> $_POST['vegetables'],
			'bakery' 		=> $_POST['bakery'],
			'drinks' 		=> $_POST['drinks'],
			'total_food' 	=> $_POST['total_food']
			);

		$goods = array(
			'cloth' 			=> $_POST['cloth'],
			'furniture' 		=> $_POST['furniture'],
			'health_care' 		=> $_POST['health_care'],
			'vehicle'		 	=> $_POST['vehicle'],
			'house_maintance' 	=> $_POST['house_maintance'],
			'total_goods'		=> $_POST['total_goods']
			);

		$args = array(
			'post_author'  => $current_user->ID,
			'post_content' => ''
		);

		$id = $_POST['post_id'];
		$post_id = 0;
		if ($_POST['new'] == 'false'):
			$args['ID'] = $id;
			$args['post_title'] = $_POST['title'];
			$post_id = wp_update_post($args);
		else:
			$args['post_status'] = 'publish';
			$args['post_type']	 = 'emission';
			$args['post_title']  = date('Y');
			$args['post_name'] 	 = time();
			$post_id = wp_insert_post($args);
		endif;

		//$post_id = isset($id)? wp_update_post($args) : wp_insert_post($args);

		// Update Meta Datas
		if ( (int)$post_id > 0 ) {
			// Travel Info
			update_post_meta($post_id, 'unit_conversion', $travel['unit_conversion']);
			update_post_meta($post_id, 'miles_year', $travel['miles_year']);
			update_post_meta($post_id, 'miles_gallon', $travel['miles_gallon']);
			update_post_meta($post_id, 'diesel', $travel['diesel']);
			update_post_meta($post_id, 'bus', $travel['bus']);
			update_post_meta($post_id, 'transit_rail', $travel['transit_rail']);
			update_post_meta($post_id, 'miles_flown', $travel['miles_flown']);
			update_post_meta($post_id, 'total_travel', $travel['total_travel']);	// total carbon used in commute per year

			// Utilities
			update_post_meta($post_id, 'electricity', $home['electricity']);
			update_post_meta($post_id, 'gas', $home['gas']);
			update_post_meta($post_id, 'term_year', $home['term_year']);
			update_post_meta($post_id, 'fuels', $home['fuels']);
			update_post_meta($post_id, 'water_used', $home['water_used']);
			update_post_meta($post_id, 'total_house', $home['total_house']);

			// Food
			update_post_meta($post_id, 'beef', $food['beef']);
			update_post_meta($post_id, 'poultry', $food['poultry']);
			update_post_meta($post_id, 'fish', $food['fish']);
			update_post_meta($post_id, 'dairy', $food['dairy']);
			update_post_meta($post_id, 'vegetables', $food['vegetables']);
			update_post_meta($post_id, 'bakery', $food['bakery']);
			update_post_meta($post_id, 'drinks', $food['drinks']);
			update_post_meta($post_id, 'total_food', $food['total_food']);

			// Shopping
			update_post_meta($post_id, 'cloth', $goods['cloth']);
			update_post_meta($post_id, 'furniture', $goods['furniture']);
			update_post_meta($post_id, 'health_care', $goods['health_care']);
			update_post_meta($post_id, 'vehicle', $goods['vehicle']);
			update_post_meta($post_id, 'house_maintance', $goods['house_maintance']);
			update_post_meta($post_id, 'total_goods', $goods['total_goods']);

			$total_emissions = $travel['total_travel'] + $home['total_house'] + $food['total_food'] + $goods['total_goods'];
			update_post_meta($post_id, 'total_emissions', $total_emissions);

			if ( isset($POST['title']) && $_POST['title'] == date('Y')):
				$this->update_user_carbon_score_meta($current_user->ID);
			endif;
		}

		die(
			json_encode(
				Array(
					'result' => ( (int) $post_id > 0 ? true : false)
				)
			)
		);
	}

	function update_user_carbon_score_meta($user_id){
		$args = array('post_type' => 'tree','author' => $user_id);
		$posts = get_posts( $args );

		$sequestered = 0;
		foreach( $posts as $post ) {
		    $tree = floatval(get_post_meta( $post->ID, 'sequestered', true ));
		    $sequestered += $tree;
		}

		$args = array('post_type' => 'emission','author' => $user_id, 'post_title' => date('Y'));
		$posts = get_posts( $args );
		$total_carbon = 0;
		foreach( $posts as $post ) {
			$total_carbon = floatval(get_post_meta( $post->ID, 'total_emissions', true ));
		}

		$carbon_score = $sequestered - $total_carbon;
		update_user_meta( $user_id, 'carbon_score', $carbon_score, $prev_value );
	}

	public function image_uploader(){

		// Set Featured Image
		require_once ABSPATH.'wp-admin/includes/file.php';
		require_once ABSPATH.'wp-admin/includes/image.php';
		//require_once ABSPATH.'wp-admin/includes/media.php';
		// $file = wp_handle_upload($_FILES['tree-image'], array('test_form'=>false));
		

		error_log($_FILES['tree-image']['name']);

		// $attachment = array(
		// 	'post_title' => $_FILES['name']
		// 	, 'post_mime_type' => $file['type']
		// 	, 'post_content' => ''
		// 	, 'post_status' => 'inherit'
		// );

		// $attach_id = wp_insert_attachment($args, $file['file']);
		// $attach_data = wp_generate_attachment_metadata( $attach_id, $file['file'] );
		// wp_update_attachment_metadata( $attach_id, $attach_data );

		// $existing_uploaded_image = (int) get_post_meta($post_id,'featured_img', true);
  //       if(is_numeric($existing_uploaded_image)):
  //           wp_delete_attachment($existing_uploaded_image);
  //       endif;

  //       $url = wp_get_attachment_image_src($img_id);
		// $url = $url[0];

  //       update_post_meta($post_id, 'featured_img', $url);

		die(
			json_encode(
				Array(
					'result' => ( (int) $post_id > 0 ? true : false)
					, 'permalink' => get_permalink($post_id)
					, 'post' => $_FILES['tree-image']['name']
				)
			)
		);
	}

}

new co2_ajax_process;
