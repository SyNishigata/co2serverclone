<?php

Class Carbon_Pages_Rewrite {

    function __construct(){
        //add rewrite rules
        add_action('init', array($this, 'plugin_rules'));
        //add plugin query vars to wordpress
        add_filter('query_vars', array($this, 'plugin_query_vars'));
        //register plugin custom pages template
        add_filter('template_include', array($this, 'plugin_page_template'));
        //add title head
        add_filter( 'wp_title', array($this, 'plugin_page_title'), 10, 2 );
    }
    
    public function plugin_rules() {
        add_rewrite_rule('my-trees/plant-a-tree', 'index.php?name=plant-a-tree', 'top');
        add_rewrite_rule('carbon/([^/]*)/?$', 'index.php?pagename=carbon&caction=$matches[1]', 'top');
        add_rewrite_rule('my-carbon/([^/]*)/([^/]*)/?$', 'index.php?pagename=my-carbon&member=$matches[1]&carbon-title=$matches[2]', 'top');
    }

    public function plugin_query_vars($vars) {
        $vars[] = 'carbon-title';
        $vars[] = 'member';
        $vars[] = 'caction';
        return $vars;
    }

    public function plugin_page_template($template) {
      global $current_user;
      get_currentuserinfo();
 

      if (get_query_var('name') == 'plant-a-tree'):
        return TEMPL_PATH . '/tree-add-template.php';
      elseif (get_query_var('pagename') == 'carbon' && get_query_var('caction') == 'calculator'):
        return TEMPL_PATH . '/carbon-tab-template.php';
      elseif (get_query_var('pagename') == 'my-carbon'):
        return TEMPL_PATH . '/carbon-tab-template.php';
      else:
        return $template;
      endif;
     }

    public function plugin_page_title( $title, $sep ) {
        if ( is_feed() ) {
            return $title;
        }
         
        if (get_query_var('name') == 'plant-a-tree'):
            return 'Plant a Tree';
        elseif (get_query_var('pagename') == 'carbon' && get_query_var('caction') == 'calculator'):
            return 'Carbon Calculator';
        else:
          return $title;
        endif;
    }
}

new Carbon_Pages_Rewrite;

