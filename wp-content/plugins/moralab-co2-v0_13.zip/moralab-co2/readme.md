<html>
<head>
	<title></title>
</head>
<body>
<h2>Custom CO2 Plugin</h2>

<p>The following are acceptable shortcodes:</p>

<p>[co2_chart] - display a&nbsp;bar graph of the total consumption of a current user.</p>

<p>[co2_summary] - displays a summary of the current user&#39;s sequestration</p>

<p>[co2_trees_display] - get list of trees by current user.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
</body>
</html>