
<div>
	<p>
		<label for="From">From: </label>
		<input type="text" name="From" id="From" onblur="calcRoute()" />
		
		<label for="To">To: </label>
		<input type="text" name="To" id="To" onblur="calcRoute()"/>				
	</p>
	<p>
		<label for="distance">Distance (km): </label>
		<input type="text" name="distance" id="distance" readonly="true" />
	</p>
</div>
