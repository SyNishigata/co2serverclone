<div id="latlong">
    <p>Latitude: <input size="15"  id="latbox" name="lat" onblur="initialize()"></p>
    <p>Longitude: <input size="15" id="lngbox" name="long" onblur="initialize()"></p>
</div>

<center><p>Drag, zoom in and drag marker as close to tree planting location</p></center> 
<center><div id="mapCanvas" style="width:500px;height:380px;"></div></center>
