<?php global $carbon_data; ?>

<div class="form-group">

    <div><p>How many servings do you eat?</p></div>

    <div class="input-group">
        <span class="input-group-addon lamb"> Do you recycle? </span>
        <select name="recycling" onchange="carbon_recycle()" id="recycling">
            <option value="a">Not much</options>
            <option value="b">Some of our waste</options>
            <option value="c">All materials locally recyclable</options>
        </select>
    </div>

    <div class="input-group">
        <span class="input-group-addon lamb"> Do You Compost? </span>
        <select name="compost" onchange="carbon_recycle()" id="compost">
            <option value="a">Rarely</options>
            <option value="b">Sometimes</options>
            <option value="c">Whenever Possible</options>
        </select>
    </div>

    <div class="input-group">               
        <input type="hidden" name="co2_recycle" id="co2_recycle" value="<?php echo !empty($carbon_data)? get_post_meta($carbon_data['ID'], 'co2_recycle', true):'';?>">
    </div>

</div>