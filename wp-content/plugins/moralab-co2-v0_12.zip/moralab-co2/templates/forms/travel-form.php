<?php global $carbon_data; ?>

<div class="form-group">

    <div class="input-group">
        <input type="hidden" name="car" id="car" value="">     
        <input type="hidden" name="bike" id="bike" value="">                  
        <input type="hidden" name="bus" id="bus" value="">                  
        <input type="hidden" name="train" id="train" value="">   
        <input type="hidden" name="plane" id="plane" value="">                
        <input type="hidden" name="co2_travel" id="co2_travel" value="">
    </div>

    <ul class="tabs" data-tabs id="travel-tabs">
        <li class="tabs-title is-active"><a href="#carpanel" aria-selected="true">Car</a></li>
        <li class="tabs-title"><a href="#bikepanel">Motorcyle</a></li>
        <li class="tabs-title"><a href="#buspanel" onblur="mapInit('busmap', 'bfrom', 'bto')">Bus</a></li>
        <li class="tabs-title"><a href="#trainpanel" onblur="mapInit('trainmap', 'rfrom', 'rto')">Train</a></li>
        <li class="tabs-title"><a href="#planepanel" onblur="mapInit('planemap', 'pfrom', 'pto' )">Plane</a></li>
    </ul>

    <div class="tabs-content home-tabs" data-tabs-content="travel-tabs">
        <div class="tabs-panel is-active" id="carpanel">
            <!-- Car Form -->
            <div class="input-group">
                <span class="input-group-addon"> What is your total year's car mileage? </span>
                <div class="row">
                    <div class="small-7 columns">
                        <input type="text" name="car_miles" onchange="carbon_car()" id="car_miles" class="form-control" value="1">
                    </div>
                    <div class="small-5 columns">
                        <select name="car_unit" onchange="carbon_car()" id="car_unit" class="form-control" value="">
                            <option value="miles">miles</option>
                            <option value="kn">km</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="input-group">
                <span class="input-group-addon"> Need Help Calculating Your Car Mileage? </span>
                <div class="button" id="show_calc_car" helper="off"><strong>Calculate</strong></div>
            </div>

            <div class="input-group" id="car_helper" style="display:none">
                <div class="row">
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Vehicle mileage at last safety/oil check</span>
                        <input type="number" name="car_last" onchange="carbon_car()" id="car_last" value="" >
                    </div>
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Enter the date of last check</span>
                        <input type="text" name="car_last_date" onchange="carbon_car()" id="car_last_date" value="" class="datepick">
                    </div>
                </div>
                <div class="row">
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Current vehicle mileage </span>
                        <input type="number" name="car_current" onchange="carbon_car()" id="car_current" value="">
                    </div>
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Enter the date of current safety/oil check</span>
                        <input type="text" name="car_current_date" onchange="carbon_car()" id="car_current_date" value="" class="datepick">
                    </div>
                </div>
            </div>

            <div class="input-group">
                <span class="input-group-addon"> Select the fuel type for your car? </span>
                <select name="car_fuel" onchange="carbon_car()" id="car_fuel" class="form-control" value="">
                    <option value="gasoline">gasoline</option>
                    <option value="other">other</option>
                </select>
            </div>

            <div class="input-group">
                <span class="input-group-addon"> What is your car's fuel efficiency? i.e. 40 miles per gallons</span>
                <input type="text" name="car_fuel_efficiency" onchange="carbon_car()" id="car_fuel_efficiency" class="form-control" value="">
            </div>
            <!-- .Car Form -->
        </div>
        <div class="tabs-panel" id="bikepanel">

            <!-- Motorcycle Form -->

            <div class="input-group">
                <span class="input-group-addon"> What is your total year's motorcycle mileage? </span>
                <input type="text" name="mcycl_miles" onchange="carbon_mcycl()" id="mcycl_miles" class="form-control" value="">
            </div>

            <div class="input-group">
                <span class="input-group-addon"> What is the CC of your motorcycle? </span>
                <select name="mcycl_cc" onchange="carbon_mcycl()" id="mcycl_cc" class="form-control" value="">
                    <option value="125">&lt;125</option>
                    <option value="375">125-500</option>
                    <option value="500">&gt;500</option>
                </select>
            </div>
            
            <div class="input-group">
                <span class="input-group-addon"> Need Help Calculating Your Motorcycle Mileage? </span>
                <div class="button" id="show_calc_bike" helper="off"><strong>Calculate</strong></div>
            </div>

            <div class="input-group" id="bike_helper" style="display:none">
                <div class="row">
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Vehicle mileage at last safety/oil check</span>
                        <input type="number" name="mcycl_last" onchange="carbon_mcycl()" id="mcycl_last" value="" >
                    </div>
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Enter the date of last check</span>
                        <input type="text" name="mcycl_last_date" onchange="carbon_mcycl()" id="mcycl_last_date" value="" class="datepick">
                    </div>
                </div>
                <div class="row">
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Current vehicle mileage </span>
                        <input type="number" name="mcycl_current" onchange="carbon_mcycl()" id="mcycl_current" value="">
                    </div>
                    <div class="small-6 columns">
                        <span class="input-group-addon"> Enter the date of current safety/oil check</span>
                        <input type="text" name="mcycl_current_date" onchange="carbon_mcycl()" id="mcycl_current_date" value="" class="datepick">
                    </div>
                </div>
            </div>

            <!-- .Motorcycle Form -->

        </div>
        <div class="tabs-panel" id="buspanel">

            <!-- Bus Form -->
            <span class="input-group-addon"><h3>Bus Routes</h3></span>
            <div class="row">
                <div class="small-6 columns">
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">From</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="bfrom" onchange="carbon_bus()" onblur="calcRoute('bfrom', 'bto', 'bdist', 'bus')" id="bfrom" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">To</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="bto" onchange="carbon_bus()" onblur="calcRoute('bfrom', 'bto', 'bdist', 'bus')" id="bto" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-4 columns">I make this trip</div>
                        <div class="small-2 columns"><input type="text" name="bus_trip" onchange="carbon_bus()" id="bus_trip" value="" length="4"></div>
                        <div class="small-6 columns">times per year.</div>
                    </div>
                    <div class="input-group row">
                        <div class="small-3 columns">Roundtrip</div>
                        <div class="small-9 columns"><input type="checkbox" name="bus_rt" onchange="carbon_bus()" id="bus_rt" length="4"></div>
                    </div>
                    <div class="input-group row">
                        <div class="button" id="add_bus_route">Add Route</div>
                        <input type="hidden" name="bdist" id="bdist">    
                    </div>
                     
                </div>
                <div class="small-6 columns">

                    <div id="busmap"></div>
                </div>
            </div> 
            <div class="row">
                <div class="routes" id="bus_routes"></div>
            </div>
            <!-- .Bus Form -->

        </div>
        <div class="tabs-panel" id="trainpanel">

            <!-- Train Form -->
            <span class="input-group-addon"><h3>Train Routes</h3></span>
            <div class="row">
                <div class="small-6 columns">
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">From</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="rfrom" onchange="carbon_bus()" onblur="calcRoute('rfrom', 'rto', 'rdist', 'train')" id="rfrom" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">To</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="rto" onchange="carbon_bus()" onblur="calcRoute('rfrom', 'rto', 'rdist', 'train')" id="rto" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-4 columns">I make this trip</div>
                        <div class="small-2 columns"><input type="text" name="rail_trip" onchange="carbon_bus()" id="rail_trip" value="" length="4"></div>
                        <div class="small-6 columns">times per year.</div>
                    </div>
                    <div class="input-group row">
                        <div class="small-3 columns">Roundtrip</div>
                        <div class="small-9 columns"><input type="checkbox" name="rail_rt" onchange="carbon_bus()" id="rail_rt" length="4"></div>
                    </div>
                    <div class="input-group row">
                        <div class="button" id="add_bus_route">Add Route</div>
                        <input type="hidden" name="rdist" id="rdist">    
                    </div>
                     
                </div>
                <div class="small-6 columns">

                    <div id="trainmap"></div>
                </div>
            </div> 
            <div class="row">
                <div class="routes" id="bus_routes"></div>
            </div>
            <!-- .Train Form -->

        </div>
        <div class="tabs-panel" id="planepanel">

            <!-- Plane Form -->
            <span class="input-group-addon"><h3>Flight Routes</h3></span>
            <div class="row">
                <div class="small-6 columns">
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">From</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="pfrom" onchange="carbon_bus()" onblur="calcRoute('pfrom', 'pto', 'pdist', 'plane')" id="pfrom" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-2 columns">
                            <span class="input-group-addon">To</span>
                        </div>
                        <div class="small-10 columns">
                            <input type="text" name="pto" onchange="carbon_bus()" onblur="calcRoute('pfrom', 'pto', 'pdist', 'plane')" id="pto" value="">
                        </div>
                    </div>
                    <div class="input-group row">
                        <div class="small-4 columns">I make this trip</div>
                        <div class="small-2 columns"><input type="text" name="bus_trip" onchange="carbon_bus()" id="bus_trip" value="" length="4"></div>
                        <div class="small-6 columns">times per year.</div>
                    </div>
                    <div class="input-group row">
                        <div class="small-3 columns">Roundtrip</div>
                        <div class="small-9 columns"><input type="checkbox" name="bus_rt" onchange="carbon_bus()" id="bus_rt" length="4"></div>
                    </div>
                    <div class="input-group row">
                        <div class="button" id="add_bus_route">Add Route</div>
                        <input type="hidden" name="pdist" id="pdist">    
                    </div>
                     
                </div>
                <div class="small-6 columns">

                    <div id="planemap"></div>
                </div>
            </div> 
            <div class="row">
                <div class="routes" id="bus_routes"></div>
            </div>

            <!-- .Plane Form -->

        </div>
          
    </div>

</div>

<script type="text/javascript">
    var directionDisplay;
    var directionsService = new google.maps.DirectionsService;
    var geocoder; 
    function mapInit( map_canvas, from, to) {
        var inputFrom = document.getElementById(from);
        var autocomplete = new google.maps.places.Autocomplete(inputFrom);

        var inputTo = document.getElementById(to);
        var autocomplete = new google.maps.places.Autocomplete(inputTo);


    
        geocoder = new new google.maps.Geocoder();
        directionsDisplay = new google.maps.DirectionsRenderer;

        var center_map = new google.maps.LatLng(41.850033, -87.6500523);
        var map = new google.maps.Map(document.getElementById( map_canvas ), 
        {zoom:2, zoomControl: true, streetViewControl:false, mapTypeId: google.maps.MapTypeId.ROADMAP, center: center_map});
        
        directionsDisplay.setMap(map);
    }

    function calcRoute(from, to, distance, type) {

        
        var From = document.getElementById(from).value;           
        var To = document.getElementById(to).value;
        var distanceInput = document.getElementById(distance);

        var travelMode = google.maps.DirectionsTravelMode.TRANSIT;

        if (type == 'plane'){
            geocoder.geocode();
        }

        else {
            var request = {
                origin:From, 
                destination:To,
                travelMode: travelMode
            };
            
            directionsService.route(request, function(response, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                    distanceInput.value = response.routes[0].legs[0].distance.value / 1000;
                }
            });
        }
    }


    jQuery(function($){
        //mapInit();

        $('#add_bus_route').on("click", function(){

            var copy = '<li style="text-decoration:none">From A to B, x times a year round trip, y miles</li>';
            $('#bus_routes').append(copy);

        });
        $('#add_train_route').on("click", function(){

        });
        $('#add_plane_route').on("click", function(){

        });

    });
</script>
