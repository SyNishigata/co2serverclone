<?php 

	if ( is_user_logged_in() ):
		global $wp_post_types;
		
		get_header();
		
		$obj = $wp_post_types['tree'];

		//get_plugin_template('tree-item-template');?>

		<div class="content">
			<div class="container">
				<div class="row" style="background-color:#ededed; margin: 10px auto">
					<a class="button pull-right" href="<?php echo get_home_url().'/my-trees/plant-a-tree';?>">Add Tree</a>
				</div>
				<div class="row">
					  <!-- <li class="grid-th"><img class="th" src="http://www.trees4life.ca/wp-content/uploads/2012/07/Tree-icon.png"></li> -->
					  <?php co2_get_users_trees(); ?>
				</div>
			</div>
		</div>

	<?php get_footer();

	else:
		wp_redirect( get_home_url() );
		exit;
	endif;