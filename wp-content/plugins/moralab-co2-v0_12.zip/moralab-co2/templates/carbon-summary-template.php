<?php 
global $current_user;
get_currentuserinfo();
$trees = get_total_sequestered();
$carbon_total = get_total_carbon_emitted();

$rankings = carbon_ranking();

$myrank = array_search($current_user->ID, array_column($rankings, 'user_id')) + 1;

$prev = 0;
$next = 0;
$last = count($rankings);
switch($myrank){
	case 1:
	case 2:
		$prev = 0;
		$next = 5;
		break;
	case ($last-1):
	case $last:
		$prev = $last-6;
		$next = $last-1;
		break;
	default:
		$prev = $myrank - 3;
		$next = $myrank + 3;
		break;
}

add_action('wp_footer', 'graph_script');
get_header(); ?>

<div class="content">
	<div class="container" style="margin-bottom:20px;">
		<!-- Title Header -->
    	<div class="panel-heading"><center><h1 style="margin0px">My Pathway to Carbon Neutrality</h1></center></div>

    	<div class="panel-body">
        	
        	<div class="row">   

        		<!-- Summary -->
        		<div class="small-4 large-4 columns">
        			<div class="section group">
						<div class="section-title">
							<h2><?php //_e('My Carbon Emission', 'moralabs-plugins');?></h2>
						</div>
						<div id="data-bar-graph" style="width:100%x; height:200px; margin: 0 auto; margin-left:-15px;"></div>
					</div>
        		</div>

        		<div class="small-4 large-4 columns">
        			<div class="section group">
        				<div class="summary">
		        			<?php 
							$deficit =  floatval($trees['total_sequestered']) - floatval($carbon_total);
		        			if ($deficit > 0.0):
		        				//Not Carbon Neutral
		        				$avg_sequestered = $trees['total_sequestered'] / $trees['count'];
		        				$trees_needed = $deficit / $avg_sequestered; ?>
		        				<h2><center>You need to plant atleast <br/><?php echo intval($trees_needed); ?> trees <br/>to be carbon neutral</center></h2>
		        			<?php else: // Is Carbon Neutral?>
		        				<h2><center>You have enough trees to sequester all of your carbon footprint</center></h2>
		        			<?php endif;?>
		        		</div>
		        		<div id="wrapper" style="text-align: center">    
		        			<div class="button planttree" style="display:inline-block"><strong>Plant A Tree</strong></div>
		        		</div>
		        	</div>
        		</div>


        		<div class="small-4 large-4 columns" style="height:inherit">
        			<div class="section group">
						<div class="section-title">
							
						</div>
						<div class="summary">

							<?php if ($trees['total_sequestered'] < $carbon_total || $carbon_total <= 0): ?>
								<h2><center>You still have <br/><?php echo $deficit;?> Co2 ton</br/> still to sequester.</center></h2>
							<?php else: ?>
								<h2><center><strong>Congratulations,<br/>You Are Carbon Neutral!</strong><center></h2>
							<?php endif; ?>
						</div>
		        		<div id="wrapper" style="text-align: center">    
							<div class="button mycarbon" style="display:inline-block"><strong>My Carbon Emissions</strong></div>
						</div>
					</div>
        		</div><!-- .Summary -->

    		</div>

    		<div class="row">

        		<!-- Ranking -->
        		<div class="section group">
        			<div class="section-title">
						<h2><?php _e('Where Do I Rank?', 'moralabs-plugins');?></h2>
					</div>

	        		<div class="ranking">
						<?php
							$ends = array('th','st','nd','rd','th','th','th','th','th','th');
							if (($myrank %100) >= 11 && ($rank%100) <= 13)
							   $ordinal_rank = $myrank. 'th';
							else
							   $ordinal_rank = $myrank. $ends[$myrank % 10];
						?>
						<p><center><strong>You are the top <?php echo $ordinal_rank; ?> most carbon neutral person.</strong></center></p>
						<div class="avatars">
							<div class="row">
								<div class="small-1 columns nav" id="prev" data-prev="<?php echo $prev; ?>"><img src="<?php echo INCLUDES_URL.'/img/prev.png';?>" style="margin:100% auto"></div>
									<div class="small-10 columns" id="members">
										<?php for($i = $prev+1; $i <= $next; $i ++ ) { ?>
										<div class="avatar-list">
											<div class="avatar"><?php echo $rankings[$i]['rank']?><img src="<?php echo $rankings[$i]['avatar']; ?>" width="100" height="100"></div>
											<div class="name"><center><?php echo $rankings[$i]['user_login']; ?></center></div>
											<div class="sequestered"><center><?php echo floatval($rankings[$i]['meta_value']) * -1; ?> <br/>ton deficit</center></div>
										</div>
										<?php } ?>
									</div>
								<div class="small-1 columns nav" id="next" data-next="<?php echo $next; ?>"><img src="<?php echo INCLUDES_URL.'/img/next.png';?>" style="margin:100% auto"></div>
							</div>
						</div>
						
					</div>
				</div><!-- .Ranking -->

    		</div>

    		<div class="row">

        		<!-- Trees -->
        		<div class="section group">
					<div class="section-title">
						<h2><?php _e('My Trees', 'moralabs-plugins');?></h2>
					</div>
					<div class="the-trees">
						<ul class="small-block-grid-2 medium-block-grid-3 large-block-grid-4" style="margin-left:0;">
						  <!-- <li class="grid-th"><img class="th" src="http://www.trees4life.ca/wp-content/uploads/2012/07/Tree-icon.png"></li> -->
						  <?php get_users_trees_short(); ?>
						</ul>
					</div>
				<div><!-- .Trees -->

    		</div>


	    </div>
	</div>
</div>


<script>
jQuery(function ($) {
    $(".mycarbon").on("click", function(){
     	window.location = "<?php echo get_home_url().'/my-carbon/'.$current_user->user_login.'/'.date('Y')?>";
    });

    $(".planttree").on("click", function(){
     	window.location = "<?php echo get_home_url().'/my-trees/plant-a-tree'?>";
    });


    $('#prev').click(function(){
			var max = 5;
			var last_index = parseInt($(this).attr("data-prev"));
			var first_index = last_index - max + 1;

			var update_list = '';
			var members = <?php echo json_encode($rankings); ?>;

			if (last_index > 0){
				if (first_index < 0 ){
					first_index = 0;
					last_index = max;
				}

				$('div#next').attr("data-next", last_index + 1);
				$('div#prev').attr("data-prev", first_index );
				
				for (i = 0; i < max; i++) { 
				    //update_list = update_list + '<div class="members-profile">' + member[first_index]['Name'] + '</div>'; 
				    // update_list = '<div class="small-2 columns"><div class="avatar"><img src="'+ 
				    // 	members[first_index]["avatar"] + '" width="100" height="100"></div><div class="name"><center>' + 
				    // 	members[first_index]["user_login"] + '</center></div><div class="sequestered"><center>' + 
				    // 	members[first_index]["meta_value"] + '</center></div></div>'
				    var rank = members[first_index]["rank"];
				    var avatar = members[first_index]["avatar"];
				    var name = members[first_index]["user_login"];
				    var deficit = members[first_index]["meta_value"];
				    update_list = update_list + '<div class="avatar-list"><div class="avatar">' + rank + '<img src="'+ 
				    	avatar + '" width="100" height="100"></div><div class="name"><center>' + 
				    	name + '</center></div><div class="sequestered"><center>' + 
				    	deficit * (-1) + '<br/>ton deficit</center></div></div>';
				    first_index++;
				}

				

				$('div#members').html(update_list);
			}

		});

		$('#next').click(function(){
			var max = 5;
			var first_index = parseInt($(this).attr("data-next"));
			
			var members = <?php echo json_encode($rankings); ?>;
			var update_list = '';

			if (first_index < members.length){
				if ((first_index + max) > members.length){
					first_index = members.length - 5;
				}

				$('#prev').attr("data-prev", first_index-1);

				for (i = 0; i < max; i++) { 
				    //update_list = update_list + '<div class="members-profile">' + member[first_index]['Name'] + '</div>';
				    var rank = members[first_index]["rank"];
				    var avatar = members[first_index]["avatar"];
				    var name = members[first_index]["user_login"];
				    var deficit = members[first_index]["meta_value"];
				    update_list = update_list + '<div class="avatar-list"><div class="avatar">' + rank +  '<img src="'+ 
				    	avatar + '" width="100" height="100"></div><div class="name"><center>' + 
				    	name + '</center></div><div class="sequestered"><center>' + 
				    	deficit * (-1) + '<br/>ton deficit</center></div></div>';
				    first_index++;
				}

				$(this).attr("data-next", first_index);


				$('div#members').html(update_list);
			}
		});
});
</script>
<?php get_footer(); ?>
