jQuery(document).foundation();

