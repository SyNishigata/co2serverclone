function total_carbon_transport(){
    

}

function carbon_car(){}
function carbon_bike(){}
function carbon_bus(){}
function carbon_train(){}
function carbon_plane(){}

function total_carbon_housing(){
    var household_members = isNaN(parseInt(document.getElementById('household').value)) ? 1:parseInt(document.getElementById('household').value);
    var total_electric = isNaN(parseFloat(document.getElementById('electric').value)) ? 0.0:parseFloat(document.getElementById('electric').value);
    var total_natural_gas = isNaN(parseFloat(document.getElementById('natural_gas').value)) ? 0.0:parseFloat(document.getElementById('natural_gas').value);
    var total_propane_fuel = isNaN(parseFloat(document.getElementById('propane_fuel').value)) ? 0.0:parseFloat(document.getElementById('propane_fuel').value);
    var total_water = isNaN(parseFloat(document.getElementById('water').value)) ? 0.0:parseFloat(document.getElementById('water').value);

    var total = (total_electric + total_water + total_natural_gas + total_propane_fuel) / household_members;

    jQuery('#co2_house').val(total.toFixed(2));
    document.getElementById("house").innerHTML = total.toFixed(2);
    jQuery('#dishouse').hide();
    jQuery('#andihouse').show();
}

// isNaN() ? 0.0:

function carbon_electric() {

    var total_carbon_electric = 0.0;
    var watts = isNaN(parseFloat(document.getElementById('watts').value)) ? 0.0:parseFloat(document.getElementById('watts').value);
    var low_watts = isNaN(parseFloat(document.getElementById('low_watts').value)) ? 0.0:parseFloat(document.getElementById('low_watts').value);
    var high_watts = isNaN(parseFloat(document.getElementById('high_watts').value)) ? 0.0:parseFloat(document.getElementById('high_watts').value);


    // calculate watts if helper is set
    if (low_watts != '' || high_watts !=''){
        watts = (low_watts + high_watts) * 6;
        jQuery('#watts').val(watts.toFixed(2));
    }
    
    // TODO: Update Data
    total_carbon_electric = watts * 835 * 1.09 * 0.000001;

    jQuery('#electric').val(total_carbon_electric.toFixed(2));
    total_carbon_housing();
}

function carbon_natural_gas() {
    // total carbon usage
    var total_carbon_natural_gas = parseFloat(document.getElementById('natural_gas').value);

    // calculation variables
    var units = isNaN(document.getElementById('gas_unit').value) ? 'ccf':(document.getElementById('gas_unit').value);
    var natural_gas = isNaN(parseFloat(document.getElementById('ngas_usage').value)) ? 0.0:parseFloat(document.getElementById('ngas_usage').value);
    var low_ngas = isNaN(parseFloat(document.getElementById('low_ngas').value)) ? 0.0:parseFloat(document.getElementById('low_ngas').value);
    var high_ngas = isNaN(parseFloat(document.getElementById('high_ngas').value)) ? 0.0:parseFloat(document.getElementById('high_ngas').value);


    if (low_watts != '' || high_watts !=''){
        switch(units){
            case 'mcf':
                natural_gas = (low_ngas + high_ngas) * 6 * 0.1;
                break;
            case 'btu':
                natural_gas = (low_ngas + high_ngas) * 6 * 102800;
                break;
            case 'therms':
                natural_gas = (low_ngas + high_ngas) * 6 * 1.028;
                break;
            case 'kwh':
                natural_gas = (low_ngas + high_ngas) * 6 * 29.31;
                break;          
            default:
                natural_gas = (low_ngas + high_ngas) * 6;
        }
    }


    total_carbon_natural_gas = (natural_gas / 100) * 54.7 * 1.14 * 0.000001;
    jQuery('#natural_gas').val(total_carbon_natural_gas.toFixed(2));
    total_carbon_housing();
}

function carbon_propane_fuel() {
    var total_carbon_propane_fuel = parseFloat(document.getElementById('propane_fuel').value);

    var cooking = (document.getElementById('cooking').checked);
    var drying = (document.getElementById('drying').checked);
    var water_heat = (document.getElementById('water_heat').checked);

    var gallons = 0;

    if (cooking == true){ gallons += 50; }
    if (drying == true) { gallons += 100; }
    if (water_heat == true) { gallons += 350; }

    if (gallons > 0){
        total_carbon_propane_fuel = gallons * 8362 * 0.000001;
    }
    jQuery('#propane_fuel').val(total_carbon_propane_fuel.toFixed(2));
    total_carbon_housing();
}


function carbon_water() {

    var total_carbon_water = 0.0;
    var water_usage = isNaN(parseFloat(document.getElementById('water_usage').value)) ? 0.0:parseFloat(document.getElementById('water_usage').value);

    var units = (document.getElementById('water_unit').value);
    var low_water = isNaN(parseFloat(document.getElementById('low_water').value)) ? 0.0:parseFloat(document.getElementById('low_water').value);
    var high_water = isNaN(parseFloat(document.getElementById('high_water').value)) ? 0.0:parseFloat(document.getElementById('high_water').value);

    if (low_water > 0 || high_water > 0 ){
        water_usage = (low_water + high_water) * 6;
        jQuery('#water_usage').val(water_usage.toFixed(2));
    }


    //if (water_usage > 0){
        switch(units){
            case 'tgals':
                total_carbon_water = water_usage * 1000 * 4.082 * 0.000001;
                break;
            default:
                total_carbon_water = water_usage * 4.082 * 0.000001;
                break;
        }
    //}


    jQuery('#water').val(total_carbon_water.toFixed(2));
    total_carbon_housing();
}

function carbon_food(){
    var food = 0.0;
    var lamb = isNaN(parseFloat(document.getElementById('lamb').value)) ? 0.0:parseFloat(document.getElementById('lamb').value)*0.11*52;
    var beef = isNaN(parseFloat(document.getElementById('beef').value)) ? 0.0:parseFloat(document.getElementById('beef').value)*0.11*52;
    var pork = isNaN(parseFloat(document.getElementById('pork').value)) ? 0.0:parseFloat(document.getElementById('pork').value)*0.11*52;
    var fish = isNaN(parseFloat(document.getElementById('fish').value)) ? 0.0:parseFloat(document.getElementById('fish').value)*0.11*52;
    var poultry = isNaN(parseFloat(document.getElementById('poultry').value)) ? 0.0:parseFloat(document.getElementById('poultry').value)*0.11*52;
    var veggies = (document.getElementById('veggies').value);

    food = 0.9 + (lamb*3.92*0.001) + (beef*27*0.001) + (pork*12.1*0.001) + (fish*11.9*0.001) + (poultry*6.9*0.001);
    jQuery('#co2_food').val(food.toFixed(2));
    document.getElementById("food").innerHTML = food.toFixed(2);
    jQuery('#disfood').hide();
    jQuery('#andifood').show();
}


function carbon_recycle(){
    var co2_recycle = 1.2;

    var recyling = (document.getElementById('recycling').value);
    var compost = (document.getElementById('compost').value);

    if (recyling == 'a'){
        co2_recycle += 0;
    }
    else if (recyling == 'b'){
        co2_recycle -= 0.2;
    }
    else {
        co2_recycle -= 0.5;
    }


    if (compost == 'a'){
        co2_recycle += 0;
    }
    else if (compost == 'b'){
        co2_recycle -= 0.1;
    }
    else {
        co2_recycle -= 0.3;
    }


    jQuery('#co2_recycle').val(co2_recycle.toFixed(2));
    document.getElementById("recycle").innerHTML = co2_recycle.toFixed(2);
    jQuery('#disrecycle').hide();
    jQuery('#andirecycle').show();
}

jQuery("#show_calc_car").on("click", function(){
    if (jQuery(this).attr("helper") == "off"){
        jQuery(this).attr("helper", "on");
        jQuery("#car_helper").show();
    }
    else {
        jQuery(this).attr("helper", "off");
        jQuery("#car_helper").hide();
    }
});


jQuery("#show_calc_electric").on("click", function(){
    if (jQuery(this).attr("helper") == "off"){
        jQuery(this).attr("helper", "on");
        jQuery("#electric_helper").show();
    }
    else {
        jQuery(this).attr("helper", "off");
        jQuery("#electric_helper").hide();
    }
});

jQuery("#show_gas_help").on("click", function(){
    if (jQuery(this).attr("helper") == "off"){
        jQuery(this).attr("helper", "on");
        jQuery("#gas_helper").show();
    }
    else {
        jQuery(this).attr("helper", "off");
        jQuery("#gas_helper").hide();
    }
});

jQuery("#show_propane_help").on("click", function(){
    if (jQuery(this).attr("helper") == "off"){
        jQuery(this).attr("helper", "on");
        jQuery("#propane_helper").show();
    }
    else {
        jQuery(this).attr("helper", "off");
        jQuery("#propane_helper").hide();
    }
    
});

jQuery("#show_water_help").on("click", function(){
    if (jQuery(this).attr("helper") == "off"){
        jQuery(this).attr("helper", "on");
        jQuery("#water_helper").show();
    }
    else {
        jQuery(this).attr("helper", "off");
        jQuery("#water_helper").hide();
    }
    
});

jQuery("div.donext").on("click", function(){
    if (jQuery(this).hasClass("fromtravel")) {
        jQuery('#example-tabs div a')[1].click();
    }
    else if (jQuery(this).hasClass("fromhome")) {
        jQuery('#example-tabs div a')[2].click();
    }
    else {
        jQuery('#example-tabs div a')[3].click();
    }

});

jQuery( ".datepick" ).datepicker();


