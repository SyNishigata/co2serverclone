<?php if($view_params['skip_arrow'] == 'false') return false; ?>

<div class="mk-skip-to-next" data-skin="<?php echo $view_params['skip_arrow_skin']; ?>">
	<i class="mk-jupiter-icon-arrow-down"></i>
</div>