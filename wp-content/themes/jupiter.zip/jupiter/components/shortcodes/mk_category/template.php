<div class="grid--float">
	<section class="mk-category-loop js-el" data-mk-component="Category">
		<article class="mk-loop-item">
			<figure class="item-holder">
				<img class="item-thumbnail" src="">
				<figcaption>
				</figcaption>
			</figure>
		</article>
	</section>
</div>