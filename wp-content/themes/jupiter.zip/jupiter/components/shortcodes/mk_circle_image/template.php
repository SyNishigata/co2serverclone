<div class="mk-circle-image">
	<div class="mk-circle-image__holder">

	</div>
</div>
<div class="clearboth"></div>